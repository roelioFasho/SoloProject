package com.roelio.cookit.services;
import java.util.List;
import java.util.Optional;

import com.roelio.cookit.models.Recipe;
import com.roelio.cookit.repositories.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class RecipeService {
    @Autowired
    private RecipeRepository repo;

    public Recipe findById(Long id) {

        Optional<Recipe> result = repo.findById(id);
        if(result.isPresent()) {
            return result.get();
        }

        return null;
    }


    public List<Recipe> all() {
        return repo.findAll();
    }

    public Recipe create(Recipe recipe) {
        return repo.save(recipe);
    }



    public void deleteRecipe(Long id){
        repo.deleteById(id);
    }
}
