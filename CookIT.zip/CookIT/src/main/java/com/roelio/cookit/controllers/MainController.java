package com.roelio.cookit.controllers;
import com.roelio.cookit.models.Recipe;
import com.roelio.cookit.models.Login;
import com.roelio.cookit.models.User;
import com.roelio.cookit.services.RecipeService;
import com.roelio.cookit.services.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class MainController {
    @Autowired
    private UserService users;
    @Autowired
    private RecipeService recipes;

    @GetMapping("/")
    public String index(Model model, @ModelAttribute("newUser") User newUser,
                        @ModelAttribute("newLogin") User newLogin, HttpSession session) {
        if(session.getAttribute("userId") != null) {
            return "redirect:/home";
        }

        model.addAttribute("newUser", new User());
        model.addAttribute("newLogin", new Login());
        return "index.jsp";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("newUser") User newUser,
                           BindingResult result, Model model, HttpSession session) {

        User user = users.register(newUser, result);


        if(result.hasErrors()) {
            model.addAttribute("newLogin", new Login());
            return "index.jsp";
        }

        session.setAttribute("userId", user.getId());

        return "redirect:/home";
    }

    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("newLogin") Login newLogin,
                        BindingResult result, Model model, HttpSession session) {

        User user = users.login(newLogin, result);

        if(result.hasErrors()) {
            model.addAttribute("newUser", new User());
            return "index.jsp";
        }

        session.setAttribute("userId", user.getId());

        return "redirect:/home";
    }

    @GetMapping("/home")
    public String home(Model model, HttpSession session) {

        if(session.getAttribute("userId") == null) {
            return "redirect:/";
        }

        model.addAttribute("books", recipes.all());
        model.addAttribute("user", users.findById((Long)session.getAttribute("userId")));
        return "home.jsp";
    }

    @GetMapping("/addPage")
    public String addPage(@ModelAttribute("book") Recipe recipe, Model model, HttpSession session) {

        User user = users.findById((Long)session.getAttribute("userId"));
        model.addAttribute("user", user);

        return "addPage.jsp";
    }

    @PostMapping("/recipes")
    public String createRecipe(@Valid @ModelAttribute("book") Recipe recipe, BindingResult result) {

        if (result.hasErrors()) {
            return "addPage.jsp";
        }

        recipes.create(recipe);

        return "redirect:/home";
    }



    @GetMapping("/books/{id}")
    public String bookDetail(Model model,
                             @PathVariable("id") Long id,
                             HttpSession session) {
        if(session.getAttribute("userId") == null) {
            return "redirect:/home";
        }
        Recipe recipe = recipes.findById(id);
        model.addAttribute("recipe", recipe);
        model.addAttribute("user", users.findById((Long)session.getAttribute("userId")));
        return "recipe.jsp";
    }

    @GetMapping("/recipes/{id}/edit")
    public String getEditRecipe(@PathVariable("id") Long id, Model model,HttpSession session){
        if(session.getAttribute("userId") == null) {
            return "redirect:/home";
        }
        Recipe recipeEdit = recipes.findById(id);
        model.addAttribute("recipeEdit",recipeEdit);
        return "editRecipe.jsp";
    }

    @PutMapping("/recipes/{id}/update")
    public String editRecipe(@Valid @ModelAttribute("bookEdit") Recipe recipeEdit,
                           BindingResult result, Model model,
                           @PathVariable("id") Long id, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        User userLogged = users.findById(userId);
        if (result.hasErrors()) {
            return "editRecipe.jsp";
        } else {
            recipeEdit.setUser(userLogged);
            recipes.create(recipeEdit);
            return "redirect:/home";
        }
    }

    @DeleteMapping("/recipes/{id}/delete")
    public String deleteBook(@PathVariable("id") Long id, HttpSession session) {
        recipes.deleteRecipe(id);
        return "redirect:/home";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
