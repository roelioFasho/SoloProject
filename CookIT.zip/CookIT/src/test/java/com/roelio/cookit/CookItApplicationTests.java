package com.roelio.cookit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookItApplicationTests {

    @Test
    void contextLoads() {
    }

}
